<?php

ini_set('default_charset', 'utf-8');
date_default_timezone_set ("America/Sao_Paulo");

$MySql_user="Guib";
$MySql_pass="Nkysd3m8tg"; 
$MySql_host="localhost";
$MySql_dbName="espy"; 

$conexao = mysqli_connect($MySql_host,$MySql_user,$MySql_pass,$MySql_dbName);

if($conexao == false){
    header("Location: ../../ESPy_Web/errorConexao.html");
}